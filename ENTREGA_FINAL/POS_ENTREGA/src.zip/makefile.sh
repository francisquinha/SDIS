javac -g -cp ./cling-core-2.1.0.jar:./cling-support-2.1.0.jar:./seamless-http-1.1.1.jar:./seamless-util-1.1.1.jar:./seamless-xml-1.1.1.jar:. -d ./classes */*.java
